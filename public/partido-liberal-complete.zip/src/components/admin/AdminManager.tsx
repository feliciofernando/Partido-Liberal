'use client'

import { useEffect, useState } from 'react'
import { useAdmin } from './AdminProvider'
import { LoginModal } from './LoginModal'
import { AdminPanel } from './AdminPanel'

export function AdminManager() {
  const { isAuthenticated, loading } = useAdmin()
  const [showLogin, setShowLogin] = useState(false)
  const [showPanel, setShowPanel] = useState(false)

  useEffect(() => {
    // Check if URL has ?admin parameter
    const checkAdminParam = () => {
      const urlParams = new URLSearchParams(window.location.search)
      const isAdmin = urlParams.get('admin')

      if (isAdmin === 'true' || isAdmin === '1') {
        if (isAuthenticated) {
          setShowPanel(true)
        } else {
          setShowLogin(true)
        }
      }
    }

    checkAdminParam()

    // Listen for URL changes
    const handleUrlChange = () => {
      checkAdminParam()
    }

    window.addEventListener('popstate', handleUrlChange)

    // Also check periodically for URL changes (for programmatic changes)
    const interval = setInterval(checkAdminParam, 500)

    return () => {
      window.removeEventListener('popstate', handleUrlChange)
      clearInterval(interval)
    }
  }, [isAuthenticated])

  // Close panel and remove admin from URL
  const handleClosePanel = () => {
    setShowPanel(false)
    const url = new URL(window.location.href)
    url.searchParams.delete('admin')
    window.history.replaceState({}, '', url.toString())
  }

  // Handle login success
  const handleLoginSuccess = () => {
    setShowLogin(false)
    setShowPanel(true)
  }

  if (loading) return null

  return (
    <>
      <LoginModal
        open={showLogin}
        onOpenChange={(open) => {
          setShowLogin(open)
          if (!open) {
            // Remove admin from URL if login cancelled
            const url = new URL(window.location.href)
            url.searchParams.delete('admin')
            window.history.replaceState({}, '', url.toString())
          }
        }}
      />
      {showPanel && isAuthenticated && <AdminPanel onClose={handleClosePanel} />}
    </>
  )
}

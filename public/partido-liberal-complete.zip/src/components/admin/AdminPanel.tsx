'use client'

import { useState, useEffect } from 'react'
import { useAdmin } from './AdminProvider'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  LayoutDashboard,
  Newspaper,
  Users,
  Calendar,
  FileText,
  Package,
  MessageSquare,
  Bell,
  Mail,
  LogOut,
  X,
  Loader2,
  Plus,
  Pencil,
  Trash2,
} from 'lucide-react'

// Types
interface Stats {
  news: number
  leaders: number
  events: number
  volunteers: number
  pendingVolunteers: number
  complaints: number
  pendingComplaints: number
  subscribers: number
  kitItems: number
  activeAlerts: number
}

type Section = 'dashboard' | 'news' | 'leaders' | 'events' | 'program' | 'kit' | 'volunteers' | 'complaints' | 'subscribers' | 'alerts'

const ANGOLAN_PROVINCES = [
  'Bengo', 'Benguela', 'Bié', 'Cabinda', 'Cunene', 'Cuanza Norte', 'Cuanza Sul',
  'Cuando Cubango', 'Huambo', 'Huíla', 'Luanda', 'Lunda Norte', 'Lunda Sul',
  'Malanje', 'Moxico', 'Namibe', 'Uíge', 'Zaire'
]

// Helper function to format dates consistently
function formatDate(dateStr: string): string {
  const date = new Date(dateStr)
  const day = date.getDate().toString().padStart(2, '0')
  const month = (date.getMonth() + 1).toString().padStart(2, '0')
  const year = date.getFullYear()
  return `${day}/${month}/${year}`
}

// Helper function to format numbers consistently
function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

export function AdminPanel({ onClose }: { onClose: () => void }) {
  const { user, logout } = useAdmin()
  const [section, setSection] = useState<Section>('dashboard')
  const [stats, setStats] = useState<Stats | null>(null)
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [editingItem, setEditingItem] = useState<any>(null)
  const [isFormOpen, setIsFormOpen] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [formLoading, setFormLoading] = useState(false)
  const [formData, setFormData] = useState<Record<string, any>>({})

  useEffect(() => {
    fetchStats()
    fetchSectionData(section)
  }, [section])

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/admin/stats')
      const data = await res.json()
      setStats(data.stats)
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error)
    }
  }

  const fetchSectionData = async (s: Section) => {
    setLoading(true)
    try {
      const endpoints: Record<Section, string> = {
        dashboard: '/api/admin/stats',
        news: '/api/admin/news',
        leaders: '/api/admin/leaders',
        events: '/api/admin/events',
        program: '/api/admin/program',
        kit: '/api/admin/kit',
        volunteers: '/api/admin/volunteers',
        complaints: '/api/admin/complaints',
        subscribers: '/api/admin/subscribers',
        alerts: '/api/admin/alerts',
      }

      const res = await fetch(endpoints[s])
      const result = await res.json()

      // Extract data based on section
      const dataKey = s === 'dashboard' ? 'stats' : 
                      s === 'news' ? 'news' :
                      s === 'leaders' ? 'leaders' :
                      s === 'events' ? 'events' :
                      s === 'program' ? 'programs' :
                      s === 'kit' ? 'kitItems' :
                      s === 'volunteers' ? 'volunteers' :
                      s === 'complaints' ? 'complaints' :
                      s === 'subscribers' ? 'subscribers' : 'alerts'
      
      setData(result[dataKey] || [])
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
      setData([])
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    await logout()
    onClose()
  }

  const openForm = (item?: any) => {
    setEditingItem(item || null)
    setFormData(item || {})
    setIsFormOpen(true)
  }

  const closeForm = () => {
    setEditingItem(null)
    setFormData({})
    setIsFormOpen(false)
  }

  const handleSave = async () => {
    setFormLoading(true)
    try {
      const endpoints: Record<Section, string> = {
        dashboard: '',
        news: '/api/admin/news',
        leaders: '/api/admin/leaders',
        events: '/api/admin/events',
        program: '/api/admin/program',
        kit: '/api/admin/kit',
        volunteers: '/api/admin/volunteers',
        complaints: '/api/admin/complaints',
        subscribers: '/api/admin/subscribers',
        alerts: '/api/admin/alerts',
      }

      const method = editingItem?.id ? 'PUT' : 'POST'
      const body = editingItem?.id ? { ...formData, id: editingItem.id } : formData

      await fetch(endpoints[section], {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      await fetchSectionData(section)
      await fetchStats()
      closeForm()
    } catch (error) {
      console.error('Erro ao salvar:', error)
    } finally {
      setFormLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!deleteId) return
    setFormLoading(true)

    try {
      const endpoints: Record<Section, string> = {
        dashboard: '',
        news: `/api/admin/news?id=${deleteId}`,
        leaders: `/api/admin/leaders?id=${deleteId}`,
        events: `/api/admin/events?id=${deleteId}`,
        program: `/api/admin/program?id=${deleteId}`,
        kit: `/api/admin/kit?id=${deleteId}`,
        volunteers: `/api/admin/volunteers?id=${deleteId}`,
        complaints: `/api/admin/complaints?id=${deleteId}`,
        subscribers: `/api/admin/subscribers?id=${deleteId}`,
        alerts: `/api/admin/alerts?id=${deleteId}`,
      }

      await fetch(endpoints[section], { method: 'DELETE' })
      await fetchSectionData(section)
      await fetchStats()
    } catch (error) {
      console.error('Erro ao apagar:', error)
    } finally {
      setFormLoading(false)
      setDeleteId(null)
    }
  }

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'news', label: 'Notícias', icon: Newspaper, count: stats?.news },
    { id: 'leaders', label: 'Líderes', icon: Users, count: stats?.leaders },
    { id: 'events', label: 'Eventos', icon: Calendar, count: stats?.events },
    { id: 'program', label: 'Programa', icon: FileText },
    { id: 'kit', label: 'Kit Digital', icon: Package, count: stats?.kitItems },
    { id: 'volunteers', label: 'Voluntários', icon: Users, count: stats?.pendingVolunteers },
    { id: 'complaints', label: 'Denúncias', icon: MessageSquare, count: stats?.pendingComplaints },
    { id: 'subscribers', label: 'Subscritores', icon: Mail, count: stats?.subscribers },
    { id: 'alerts', label: 'Alertas', icon: Bell, count: stats?.activeAlerts },
  ]

  const columns: Record<Section, { key: string; label: string }[]> = {
    dashboard: [],
    news: [
      { key: 'title', label: 'Título' },
      { key: 'category', label: 'Categoria' },
      { key: 'published', label: 'Publicado' },
      { key: 'views', label: 'Views' },
    ],
    leaders: [
      { key: 'name', label: 'Nome' },
      { key: 'role', label: 'Cargo' },
      { key: 'province', label: 'Província' },
      { key: 'active', label: 'Ativo' },
    ],
    events: [
      { key: 'title', label: 'Título' },
      { key: 'location', label: 'Local' },
      { key: 'date', label: 'Data' },
      { key: 'status', label: 'Status' },
    ],
    program: [
      { key: 'title', label: 'Título' },
      { key: 'area', label: 'Área' },
      { key: 'order', label: 'Ordem' },
      { key: 'active', label: 'Ativo' },
    ],
    kit: [
      { key: 'title', label: 'Título' },
      { key: 'type', label: 'Tipo' },
      { key: 'downloads', label: 'Downloads' },
      { key: 'active', label: 'Ativo' },
    ],
    volunteers: [
      { key: 'name', label: 'Nome' },
      { key: 'email', label: 'Email' },
      { key: 'province', label: 'Província' },
      { key: 'status', label: 'Status' },
    ],
    complaints: [
      { key: 'type', label: 'Tipo' },
      { key: 'subject', label: 'Assunto' },
      { key: 'status', label: 'Status' },
    ],
    subscribers: [
      { key: 'email', label: 'Email' },
      { key: 'name', label: 'Nome' },
      { key: 'active', label: 'Ativo' },
      { key: 'createdAt', label: 'Data' },
    ],
    alerts: [
      { key: 'title', label: 'Título' },
      { key: 'type', label: 'Tipo' },
      { key: 'active', label: 'Ativo' },
    ],
  }

  const renderCell = (key: string, value: any) => {
    if (key === 'published' || key === 'active') {
      return value ? <Badge className="bg-green-500">Sim</Badge> : <Badge variant="secondary">Não</Badge>
    }
    if (key === 'status') {
      const colors: Record<string, string> = {
        pending: 'secondary',
        approved: 'default',
        rejected: 'destructive',
        scheduled: 'default',
        ongoing: 'secondary',
        completed: 'default',
      }
      return <Badge variant={colors[value] || 'default'}>{value}</Badge>
    }
    if (key === 'date' || key === 'createdAt') {
      return formatDate(value)
    }
    if (typeof value === 'number') {
      return formatNumber(value)
    }
    return value || '-'
  }

  return (
    <div className="fixed inset-0 z-[9999] bg-white flex flex-col">
      {/* Header */}
      <header className="h-16 border-b bg-primary text-primary-foreground flex items-center justify-between px-6 flex-shrink-0">
        <h1 className="text-xl font-bold">Painel Administrativo - Partido Liberal</h1>
        <div className="flex items-center gap-4">
          <span className="text-sm opacity-80">{user?.email}</span>
          <Button variant="secondary" size="sm" onClick={handleLogout}>
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
          <Button variant="ghost" size="sm" onClick={onClose} className="text-primary-foreground hover:bg-primary/80">
            <X className="w-4 h-4" />
          </Button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 border-r bg-muted/30 flex-shrink-0 overflow-y-auto">
          <nav className="p-4 space-y-1">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setSection(item.id as Section)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
                  section === item.id
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-muted'
                }`}
              >
                <div className="flex items-center gap-3">
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </div>
                {item.count !== undefined && item.count > 0 && (
                  <Badge variant={section === item.id ? 'secondary' : 'default'} className="text-xs">
                    {item.count}
                  </Badge>
                )}
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto p-6">
          {section === 'dashboard' ? (
            <DashboardContent stats={stats} />
          ) : (
            <>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold capitalize">{section}</h2>
                {['news', 'leaders', 'events', 'program', 'kit', 'alerts'].includes(section) && (
                  <Button onClick={() => openForm()}>
                    <Plus className="w-4 h-4 mr-2" />
                    Adicionar
                  </Button>
                )}
              </div>

              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                </div>
              ) : data.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  Nenhum registro encontrado
                </div>
              ) : (
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-muted/50">
                      <tr>
                        {columns[section]?.map((col) => (
                          <th key={col.key} className="px-4 py-3 text-left text-sm font-medium">
                            {col.label}
                          </th>
                        ))}
                        <th className="px-4 py-3 text-right text-sm font-medium">Ações</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {data.map((row) => (
                        <tr key={row.id} className="hover:bg-muted/30">
                          {columns[section]?.map((col) => (
                            <td key={col.key} className="px-4 py-3 text-sm">
                              {renderCell(col.key, row[col.key])}
                            </td>
                          ))}
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <Button variant="ghost" size="sm" onClick={() => openForm(row)}>
                                <Pencil className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="sm" onClick={() => setDeleteId(row.id)}>
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </>
          )}
        </main>
      </div>

      {/* Form Dialog */}
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingItem ? 'Editar' : 'Novo'}</DialogTitle>
          </DialogHeader>
          <FormContent
            section={section}
            formData={formData}
            setFormData={setFormData}
          />
          <div className="flex justify-end gap-3 mt-6">
            <Button variant="outline" onClick={closeForm}>Cancelar</Button>
            <Button onClick={handleSave} disabled={formLoading}>
              {formLoading && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              Salvar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este item? Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
              {formLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Excluir'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}

// Dashboard Content
function DashboardContent({ stats }: { stats: Stats | null }) {
  if (!stats) return <div>Carregando...</div>

  const cards = [
    { label: 'Notícias', value: stats.news, icon: Newspaper, color: 'text-blue-500' },
    { label: 'Líderes', value: stats.leaders, icon: Users, color: 'text-purple-500' },
    { label: 'Eventos', value: stats.events, icon: Calendar, color: 'text-green-500' },
    { label: 'Voluntários', value: stats.volunteers, icon: Users, color: 'text-orange-500', sub: `${stats.pendingVolunteers} pendentes` },
    { label: 'Denúncias', value: stats.complaints, icon: MessageSquare, color: 'text-red-500', sub: `${stats.pendingComplaints} pendentes` },
    { label: 'Subscritores', value: stats.subscribers, icon: Mail, color: 'text-cyan-500' },
    { label: 'Kit Digital', value: stats.kitItems, icon: Package, color: 'text-pink-500' },
    { label: 'Alertas Ativos', value: stats.activeAlerts, icon: Bell, color: 'text-yellow-500' },
  ]

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="bg-card border rounded-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">{card.label}</p>
                <p className="text-3xl font-bold">{formatNumber(card.value)}</p>
                {card.sub && <p className="text-xs text-muted-foreground mt-1">{card.sub}</p>}
              </div>
              <card.icon className={`w-10 h-10 ${card.color}`} />
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// Form Content
function FormContent({
  section,
  formData,
  setFormData,
}: {
  section: Section
  formData: Record<string, any>
  setFormData: (data: Record<string, any>) => void
}) {
  const updateField = (key: string, value: any) => {
    setFormData({ ...formData, [key]: value })
  }

  if (section === 'news') {
    return (
      <div className="space-y-4">
        <div><Label>Título</Label><Input value={formData.title || ''} onChange={(e) => updateField('title', e.target.value)} /></div>
        <div><Label>Resumo</Label><Textarea value={formData.summary || ''} onChange={(e) => updateField('summary', e.target.value)} /></div>
        <div><Label>Conteúdo</Label><Textarea rows={6} value={formData.content || ''} onChange={(e) => updateField('content', e.target.value)} /></div>
        <div>
          <Label>Categoria</Label>
          <Select value={formData.category || ''} onValueChange={(v) => updateField('category', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="politica">Política</SelectItem>
              <SelectItem value="economia">Economia</SelectItem>
              <SelectItem value="social">Social</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>URL da Imagem</Label><Input value={formData.image || ''} onChange={(e) => updateField('image', e.target.value)} /></div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2"><Switch checked={formData.published || false} onCheckedChange={(v) => updateField('published', v)} /><Label>Publicado</Label></div>
          <div className="flex items-center gap-2"><Switch checked={formData.featured || false} onCheckedChange={(v) => updateField('featured', v)} /><Label>Destaque</Label></div>
        </div>
      </div>
    )
  }

  if (section === 'leaders') {
    return (
      <div className="space-y-4">
        <div><Label>Nome</Label><Input value={formData.name || ''} onChange={(e) => updateField('name', e.target.value)} /></div>
        <div><Label>Cargo</Label><Input value={formData.role || ''} onChange={(e) => updateField('role', e.target.value)} /></div>
        <div>
          <Label>Província</Label>
          <Select value={formData.province || ''} onValueChange={(v) => updateField('province', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {ANGOLAN_PROVINCES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div><Label>Biografia</Label><Textarea rows={4} value={formData.bio || ''} onChange={(e) => updateField('bio', e.target.value)} /></div>
        <div><Label>URL da Foto</Label><Input value={formData.photo || ''} onChange={(e) => updateField('photo', e.target.value)} /></div>
        <div className="flex items-center gap-2"><Switch checked={formData.active || false} onCheckedChange={(v) => updateField('active', v)} /><Label>Ativo</Label></div>
      </div>
    )
  }

  if (section === 'events') {
    return (
      <div className="space-y-4">
        <div><Label>Título</Label><Input value={formData.title || ''} onChange={(e) => updateField('title', e.target.value)} /></div>
        <div><Label>Descrição</Label><Textarea rows={4} value={formData.description || ''} onChange={(e) => updateField('description', e.target.value)} /></div>
        <div className="grid grid-cols-2 gap-4">
          <div><Label>Data</Label><Input type="date" value={formData.date?.split('T')[0] || ''} onChange={(e) => updateField('date', e.target.value)} /></div>
          <div><Label>Hora</Label><Input type="time" value={formData.time || ''} onChange={(e) => updateField('time', e.target.value)} /></div>
        </div>
        <div><Label>Local</Label><Input value={formData.location || ''} onChange={(e) => updateField('location', e.target.value)} /></div>
        <div>
          <Label>Província</Label>
          <Select value={formData.province || ''} onValueChange={(v) => updateField('province', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {ANGOLAN_PROVINCES.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label>Status</Label>
          <Select value={formData.status || 'scheduled'} onValueChange={(v) => updateField('status', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="scheduled">Agendado</SelectItem>
              <SelectItem value="ongoing">Em andamento</SelectItem>
              <SelectItem value="completed">Concluído</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    )
  }

  if (section === 'alerts') {
    return (
      <div className="space-y-4">
        <div><Label>Título</Label><Input value={formData.title || ''} onChange={(e) => updateField('title', e.target.value)} /></div>
        <div><Label>Mensagem</Label><Textarea rows={3} value={formData.message || ''} onChange={(e) => updateField('message', e.target.value)} /></div>
        <div>
          <Label>Tipo</Label>
          <Select value={formData.type || 'info'} onValueChange={(v) => updateField('type', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="info">Informação</SelectItem>
              <SelectItem value="warning">Aviso</SelectItem>
              <SelectItem value="urgent">Urgente</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2"><Switch checked={formData.active || false} onCheckedChange={(v) => updateField('active', v)} /><Label>Ativo</Label></div>
      </div>
    )
  }

  if (section === 'volunteers') {
    return (
      <div className="space-y-4">
        <div><Label>Nome</Label><Input value={formData.name || ''} disabled /></div>
        <div><Label>Email</Label><Input value={formData.email || ''} disabled /></div>
        <div>
          <Label>Status</Label>
          <Select value={formData.status || 'pending'} onValueChange={(v) => updateField('status', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="approved">Aprovado</SelectItem>
              <SelectItem value="rejected">Rejeitado</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2"><Switch checked={formData.isFiscal || false} onCheckedChange={(v) => updateField('isFiscal', v)} /><Label>Fiscal Eleitoral</Label></div>
      </div>
    )
  }

  if (section === 'complaints') {
    return (
      <div className="space-y-4">
        <div><Label>Assunto</Label><Input value={formData.subject || ''} disabled /></div>
        <div><Label>Mensagem</Label><Textarea rows={4} value={formData.message || ''} disabled /></div>
        <div>
          <Label>Status</Label>
          <Select value={formData.status || 'pending'} onValueChange={(v) => updateField('status', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="in_progress">Em análise</SelectItem>
              <SelectItem value="resolved">Resolvido</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Resposta</Label><Textarea rows={4} value={formData.response || ''} onChange={(e) => updateField('response', e.target.value)} placeholder="Digite sua resposta..." /></div>
      </div>
    )
  }

  if (section === 'program') {
    return (
      <div className="space-y-4">
        <div><Label>Título</Label><Input value={formData.title || ''} onChange={(e) => updateField('title', e.target.value)} /></div>
        <div>
          <Label>Área</Label>
          <Select value={formData.area || ''} onValueChange={(v) => updateField('area', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="Educação">Educação</SelectItem>
              <SelectItem value="Saúde">Saúde</SelectItem>
              <SelectItem value="Economia">Economia</SelectItem>
              <SelectItem value="Infraestrutura">Infraestrutura</SelectItem>
              <SelectItem value="Segurança">Segurança</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>Resumo</Label><Textarea value={formData.summary || ''} onChange={(e) => updateField('summary', e.target.value)} /></div>
        <div><Label>Conteúdo</Label><Textarea rows={6} value={formData.content || ''} onChange={(e) => updateField('content', e.target.value)} /></div>
        <div className="flex items-center gap-2"><Switch checked={formData.active || false} onCheckedChange={(v) => updateField('active', v)} /><Label>Ativo</Label></div>
      </div>
    )
  }

  if (section === 'kit') {
    return (
      <div className="space-y-4">
        <div><Label>Título</Label><Input value={formData.title || ''} onChange={(e) => updateField('title', e.target.value)} /></div>
        <div><Label>Descrição</Label><Textarea value={formData.description || ''} onChange={(e) => updateField('description', e.target.value)} /></div>
        <div>
          <Label>Tipo</Label>
          <Select value={formData.type || ''} onValueChange={(v) => updateField('type', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="imagem">Imagem</SelectItem>
              <SelectItem value="documento">Documento</SelectItem>
              <SelectItem value="video">Vídeo</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div><Label>URL do Arquivo</Label><Input value={formData.fileUrl || ''} onChange={(e) => updateField('fileUrl', e.target.value)} /></div>
        <div className="flex items-center gap-2"><Switch checked={formData.active || false} onCheckedChange={(v) => updateField('active', v)} /><Label>Ativo</Label></div>
      </div>
    )
  }

  return <div className="text-muted-foreground">Selecione uma seção para editar</div>
}

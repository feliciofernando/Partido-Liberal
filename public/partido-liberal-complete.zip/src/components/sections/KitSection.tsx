"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Download, Image, FileText, Share2, Smartphone, FileImage } from "lucide-react";

// Helper function to format numbers consistently (avoid hydration mismatch)
function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

const kitItems = [
  {
    id: "1",
    title: "Avatar Oficial PL",
    description: "Foto de perfil para suas redes sociais com o símbolo do Partido Liberal.",
    type: "avatar",
    downloads: 5420,
    thumbnail: null,
  },
  {
    id: "2",
    title: "Pack de Stickers WhatsApp",
    description: "Figurinhas divertidas para usar no WhatsApp e espalhar a mensagem do PL.",
    type: "sticker",
    downloads: 8230,
    thumbnail: null,
  },
  {
    id: "3",
    title: "Banner Facebook - Campanha",
    description: "Capa para seu perfil do Facebook apoiando o Partido Liberal.",
    type: "banner",
    downloads: 3150,
    thumbnail: null,
  },
  {
    id: "4",
    title: "Flyer Digital - Eventos",
    description: "Modelo de flyer para divulgar eventos do partido nas redes sociais.",
    type: "flyer",
    downloads: 2980,
    thumbnail: null,
  },
  {
    id: "5",
    title: "Estatutos do Partido",
    description: "Documento oficial com os estatutos e regimento interno do PL.",
    type: "documento",
    downloads: 1540,
    thumbnail: null,
  },
  {
    id: "6",
    title: "Programa de Governo",
    description: "PDF completo com todas as propostas do Partido Liberal.",
    type: "documento",
    downloads: 4890,
    thumbnail: null,
  },
];

const typeIcons: Record<string, any> = {
  avatar: Image,
  sticker: Smartphone,
  banner: FileImage,
  flyer: FileImage,
  documento: FileText,
};

const typeColors: Record<string, string> = {
  avatar: "bg-blue-100 text-blue-600",
  sticker: "bg-green-100 text-green-600",
  banner: "bg-purple-100 text-purple-600",
  flyer: "bg-orange-100 text-orange-600",
  documento: "bg-red-100 text-red-600",
};

const typeLabels: Record<string, string> = {
  avatar: "Avatar",
  sticker: "Sticker",
  banner: "Banner",
  flyer: "Flyer",
  documento: "Documento",
};

export function KitSection() {
  return (
    <section id="kit" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="bg-party-yellow/20 text-party-yellow-dark mb-4">
            Kit Digital
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Kit de <span className="text-party-blue">Militância Digital</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Baixe materiais prontos para usar em suas redes sociais. Ajude a espalhar
            a mensagem do Partido Liberal para todos os angolanos!
          </p>
        </div>

        {/* Kit Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {kitItems.map((item) => (
            <Card
              key={item.id}
              className="card-hover border-0 shadow-md overflow-hidden group"
            >
              {/* Preview Area */}
              <div className="h-40 bg-gradient-to-br from-party-blue/10 to-party-yellow/10 flex items-center justify-center relative">
                {item.thumbnail ? (
                  <img
                    src={item.thumbnail}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center">
                    {(() => {
                      const IconComponent = typeIcons[item.type];
                      return <IconComponent className="h-12 w-12 text-party-blue/40 mx-auto" />;
                    })()}
                  </div>
                )}
                <Badge className={`absolute top-3 right-3 ${typeColors[item.type]}`}>
                  {typeLabels[item.type]}
                </Badge>
              </div>

              <CardContent className="p-5 space-y-4">
                <div>
                  <h3 className="font-semibold text-foreground group-hover:text-party-blue transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground flex items-center gap-1">
                    <Download className="h-4 w-4" />
                    {formatNumber(item.downloads)} downloads
                  </span>
                  <Button size="sm" className="btn-cta">
                    <Download className="h-4 w-4 mr-1" />
                    Baixar
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Share CTA */}
        <Card className="mt-12 bg-gradient-to-r from-party-blue to-party-blue-dark text-white border-0">
          <CardContent className="p-8 text-center">
            <Share2 className="h-12 w-12 mx-auto mb-4 opacity-80" />
            <h3 className="text-xl font-semibold mb-2">Compartilhe nas Redes Sociais</h3>
            <p className="text-white/80 mb-6 max-w-xl mx-auto">
              Use nossos materiais para mostrar seu apoio ao Partido Liberal.
              Juntos, somos mais fortes!
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <Button className="bg-white text-party-blue hover:bg-white/90">
                <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
                Facebook
              </Button>
              <Button className="bg-white text-party-blue hover:bg-white/90">
                <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/>
                </svg>
                Twitter
              </Button>
              <Button className="bg-green-600 hover:bg-green-700 text-white">
                <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                </svg>
                WhatsApp
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

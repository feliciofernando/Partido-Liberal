import { createClient } from "@/lib/supabase/server";

// Fallback data when Supabase tables don't exist
const mockLeaders = [
  {
    id: '1',
    name: 'Dr. António Mendes',
    slug: 'antonio-mendes',
    role: 'Presidente do Partido',
    province: 'Luanda',
    bio: 'Líder experiente com mais de 20 anos de dedicação à política angolana. Economista formado pela Universidade de Lisboa.',
    socialFacebook: '#',
    socialTwitter: '#',
    socialInstagram: '#',
    order: 1,
  },
  {
    id: '2',
    name: 'Dra. Maria Santos',
    slug: 'maria-santos',
    role: 'Vice-Presidente',
    province: 'Benguela',
    bio: 'Advogada e ativista dos direitos humanos. Pioneira na luta pela igualdade de género em Angola.',
    socialFacebook: '#',
    socialTwitter: '#',
    socialInstagram: '#',
    order: 2,
  },
  {
    id: '3',
    name: 'Eng. João Silva',
    slug: 'joao-silva',
    role: 'Secretário-Geral',
    province: 'Huambo',
    bio: 'Engenheiro civil com vasta experiência em projetos de infraestrutura.',
    socialFacebook: '#',
    socialTwitter: '#',
    socialInstagram: '#',
    order: 3,
  },
  {
    id: '4',
    name: 'Dr. Pedro Neto',
    slug: 'pedro-neto',
    role: 'Candidato a Deputado',
    province: 'Lunda Sul',
    bio: 'Médico comunitário dedicado à saúde rural.',
    socialFacebook: '#',
    socialTwitter: '#',
    order: 4,
  },
  {
    id: '5',
    name: 'Dra. Ana Costa',
    slug: 'ana-costa',
    role: 'Candidata a Deputada',
    province: 'Cabinda',
    bio: 'Professora universitária e especialista em educação.',
    socialFacebook: '#',
    socialTwitter: '#',
    socialInstagram: '#',
    order: 5,
  },
  {
    id: '6',
    name: 'Lic. Carlos Ferreira',
    slug: 'carlos-ferreira',
    role: 'Secretário de Juventude',
    province: 'Huíla',
    bio: 'Jovem líder estudantil e empreendedor.',
    socialFacebook: '#',
    socialTwitter: '#',
    socialInstagram: '#',
    order: 6,
  },
];

export async function LeadersSection() {
  const supabase = await createClient();
  
  let leaders = mockLeaders;
  
  try {
    const { data, error } = await supabase
      .from('Leader')
      .select('*')
      .eq('active', true)
      .order('order', { ascending: true })
      .limit(6);

    if (!error && data && data.length > 0) {
      leaders = data;
    }
  } catch (e) {
    // Use mock data if Supabase fails
    console.log('Using mock leaders data');
  }

  return (
    <section id="lideranca" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block px-4 py-1.5 bg-party-blue/10 text-party-blue text-sm font-medium rounded-full mb-4">
            Liderança
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Nossos <span className="text-party-blue">Líderes</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Conheça os homens e mulheres dedicados que lideram nossa luta por um Angola melhor.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {leaders.map((leader: any) => (
            <div 
              key={leader.id} 
              className="bg-card rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-all duration-300 group"
            >
              {/* Photo Area */}
              <div className="h-48 bg-gradient-to-br from-party-blue to-party-blue-dark flex items-center justify-center relative">
                {leader.photo ? (
                  <img 
                    src={leader.photo} 
                    alt={leader.name}
                    className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-lg"
                  />
                ) : (
                  <div className="w-28 h-28 rounded-full bg-party-yellow text-party-blue-dark text-3xl font-bold flex items-center justify-center border-4 border-white shadow-lg">
                    {leader.name.split(' ').map((n: string) => n[0]).join('').slice(0, 2)}
                  </div>
                )}
                {leader.province && (
                  <span className="absolute top-4 right-4 px-3 py-1 bg-party-yellow text-party-blue-dark text-xs font-medium rounded-full">
                    {leader.province}
                  </span>
                )}
              </div>

              <div className="p-6">
                <span className="inline-block px-3 py-1 border border-party-blue/20 text-party-blue text-xs font-medium rounded-full mb-2">
                  {leader.role}
                </span>
                <h3 className="text-xl font-semibold text-foreground group-hover:text-party-blue transition-colors">
                  {leader.name}
                </h3>
                <p className="text-muted-foreground text-sm mt-2 line-clamp-3">
                  {leader.bio}
                </p>

                {/* Social Links */}
                <div className="flex gap-2 mt-4">
                  {leader.socialFacebook && (
                    <a href={leader.socialFacebook} target="_blank" rel="noopener noreferrer" 
                       className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-party-blue hover:text-white transition-colors">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    </a>
                  )}
                  {leader.socialTwitter && (
                    <a href={leader.socialTwitter} target="_blank" rel="noopener noreferrer"
                       className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-party-blue hover:text-white transition-colors">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
                    </a>
                  )}
                  {leader.socialInstagram && (
                    <a href={leader.socialInstagram} target="_blank" rel="noopener noreferrer"
                       className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-party-blue hover:text-white transition-colors">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                    </a>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a href="#lideranca" className="inline-flex items-center px-6 py-3 border border-party-blue text-party-blue hover:bg-party-blue hover:text-white rounded-lg transition-colors">
            Ver Todos os Candidatos
            <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
}

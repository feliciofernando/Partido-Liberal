"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Users, Clock, CheckCircle, Loader2 } from "lucide-react";

interface Event {
  id: string;
  title: string;
  description: string;
  location: string;
  province: string;
  date: string;
  time: string;
  type: string;
  status: string;
  attendees: number;
  confirmations: number;
}

// Helper functions to avoid hydration mismatch
function formatNumber(num: number): string {
  return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

const MONTHS_PT = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

function formatMonth(dateStr: string): string {
  const date = new Date(dateStr);
  return MONTHS_PT[date.getMonth()];
}

const mockEvents: Event[] = [
  {
    id: "1",
    title: "Grande Comício em Luanda",
    description: "Lançamento oficial da campanha eleitoral com a presença de toda a liderança.",
    location: "Praça da Independência, Luanda",
    province: "Luanda",
    date: "2025-02-20",
    time: "09:00",
    type: "comicio",
    status: "agendado",
    attendees: 15000,
    confirmations: 0,
  },
  {
    id: "2",
    title: "Encontro com Jovens Empreendedores",
    description: "Discussão sobre políticas de apoio ao empreendedorismo juvenil.",
    location: "Centro de Conferências, Benguela",
    province: "Benguela",
    date: "2025-02-22",
    time: "14:00",
    type: "encontro",
    status: "agendado",
    attendees: 500,
    confirmations: 0,
  },
  {
    id: "3",
    title: "Passeata pela Paz",
    description: "Caminhada pacífica em defesa da democracia e tolerância.",
    location: "Avenida Principal, Huambo",
    province: "Huambo",
    date: "2025-02-25",
    time: "07:00",
    type: "passeata",
    status: "agendado",
    attendees: 3000,
    confirmations: 0,
  },
  {
    id: "4",
    title: "Reunião de Fiscais",
    description: "Capacitação para fiscais de mesa no dia da eleição.",
    location: "Sede do Partido, Saurimo",
    province: "Lunda Sul",
    date: "2025-02-18",
    time: "10:00",
    type: "reuniao",
    status: "agendado",
    attendees: 200,
    confirmations: 0,
  },
  {
    id: "5",
    title: "Comício em Cabinda",
    description: "Apresentação das propostas para a província de Cabinda.",
    location: "Estádio Municipal, Cabinda",
    province: "Cabinda",
    date: "2025-02-28",
    time: "16:00",
    type: "comicio",
    status: "agendado",
    attendees: 8000,
    confirmations: 0,
  },
];

const typeColors: Record<string, string> = {
  comicio: "bg-party-blue text-white",
  passeata: "bg-green-600 text-white",
  encontro: "bg-party-yellow text-party-blue-dark",
  reuniao: "bg-purple-600 text-white",
};

const typeLabels: Record<string, string> = {
  comicio: "Comício",
  passeata: "Passeata",
  encontro: "Encontro",
  reuniao: "Reunião",
};

export function EventsSection() {
  const [events, setEvents] = useState<Event[]>(mockEvents);
  const [confirmedEvents, setConfirmedEvents] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [confirming, setConfirming] = useState<string | null>(null);

  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await fetch("/api/events?upcoming=true");
        const data = await response.json();
        if (data.events && data.events.length > 0) {
          setEvents(data.events);
        }
      } catch (error) {
        console.log("Usando eventos de fallback");
      } finally {
        setLoading(false);
      }
    };

    fetchEvents();
  }, []);

  const toggleConfirmation = async (eventId: string) => {
    if (confirmedEvents.includes(eventId)) {
      setConfirmedEvents((prev) => prev.filter((id) => id !== eventId));
      return;
    }

    setConfirming(eventId);

    try {
      const response = await fetch("/api/events", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          eventId,
          name: "Apoiante",
        }),
      });

      if (response.ok) {
        setConfirmedEvents((prev) => [...prev, eventId]);
      }
    } catch (error) {
      console.error("Erro ao confirmar presença:", error);
      // Confirmar mesmo assim localmente
      setConfirmedEvents((prev) => [...prev, eventId]);
    } finally {
      setConfirming(null);
    }
  };

  const upcomingEvents = events.filter((e) => new Date(e.date) >= new Date());

  return (
    <section id="eventos" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="bg-party-yellow/20 text-party-yellow-dark mb-4">
            Agenda
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Próximos <span className="text-party-blue">Eventos</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Participe dos nossos eventos e faça parte da mudança. Confirme sua presença
            e ajude-nos a construir um Angola melhor.
          </p>
        </div>

        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border-0 shadow-md">
                <CardContent className="p-6">
                  <div className="animate-pulse space-y-4">
                    <div className="h-16 bg-muted rounded" />
                    <div className="h-4 bg-muted rounded w-3/4" />
                    <div className="h-4 bg-muted rounded w-1/2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {upcomingEvents.map((event) => (
              <Card
                key={event.id}
                className="card-hover border-0 shadow-md overflow-hidden"
              >
                {/* Date Header */}
                <div className="bg-party-blue text-white p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-14 h-14 rounded-lg bg-white/20 flex flex-col items-center justify-center">
                      <span className="text-xl font-bold">
                        {new Date(event.date).getDate()}
                      </span>
                      <span className="text-xs uppercase">
                        {formatMonth(event.date)}
                      </span>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 text-sm text-white/80">
                        <Clock className="h-4 w-4" />
                        {event.time}h
                      </div>
                      <Badge className={`${typeColors[event.type] || "bg-gray-500 text-white"} mt-1`}>
                        {typeLabels[event.type] || event.type}
                      </Badge>
                    </div>
                  </div>
                </div>

                <CardHeader className="pb-2">
                  <h3 className="text-lg font-semibold text-foreground">
                    {event.title}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {event.description}
                  </p>
                </CardHeader>

                <CardContent className="space-y-4">
                  <div className="space-y-2 text-sm">
                    <div className="flex items-start gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4 mt-0.5 text-party-blue" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Users className="h-4 w-4 text-party-blue" />
                      <span>{formatNumber(event.attendees || 0)} participantes esperados</span>
                    </div>
                  </div>

                  {/* Province Badge */}
                  <Badge variant="outline" className="border-party-blue/20 text-party-blue">
                    {event.province}
                  </Badge>

                  {/* Confirm Button */}
                  <Button
                    onClick={() => toggleConfirmation(event.id)}
                    disabled={confirming === event.id}
                    className={`w-full ${
                      confirmedEvents.includes(event.id)
                        ? "bg-green-600 hover:bg-green-700"
                        : "btn-cta"
                    }`}
                  >
                    {confirming === event.id ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Confirmando...
                      </>
                    ) : confirmedEvents.includes(event.id) ? (
                      <>
                        <CheckCircle className="mr-2 h-4 w-4" />
                        Presença Confirmada
                      </>
                    ) : (
                      "Confirmar Presença"
                    )}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* View All CTA */}
        <div className="text-center mt-12">
          <Button variant="outline" className="border-party-blue text-party-blue">
            <Calendar className="mr-2 h-4 w-4" />
            Ver Calendário Completo
          </Button>
        </div>
      </div>
    </section>
  );
}

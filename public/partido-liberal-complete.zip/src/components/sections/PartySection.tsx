"use client";

import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, Heart, Shield, Globe } from "lucide-react";

const values = [
  {
    icon: Target,
    title: "Liberdade",
    description: "Defendemos a liberdade individual como direito fundamental de cada cidadão.",
  },
  {
    icon: Heart,
    title: "Justiça Social",
    description: "Promovemos a igualdade de oportunidades e o bem-estar para todos os angolanos.",
  },
  {
    icon: Shield,
    title: "Democracia",
    description: "Acreditamos no poder do povo e na participação cívica ativa.",
  },
  {
    icon: Globe,
    title: "Desenvolvimento",
    description: "Buscamos o crescimento sustentável e o progresso de Angola.",
  },
];

const timeline = [
  { year: "2010", title: "Fundação", desc: "O Partido Liberal foi fundado por um grupo de cidadãos comprometidos com a mudança." },
  { year: "2015", title: "Expansão Nacional", desc: "Chegamos a todas as 18 províncias de Angola." },
  { year: "2020", title: "Crescimento Expressivo", desc: "Triplicamos o número de membros e apoiantes." },
  { year: "2025", title: "Presente", desc: "Preparados para as eleições com propostas inovadoras." },
];

export function PartySection() {
  return (
    <section id="partido" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="bg-party-yellow/20 text-party-yellow-dark mb-4">
            O Partido
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Conheça o <span className="text-party-blue">Partido Liberal</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Fundado com a missão de transformar Angola em uma nação próspera e justa,
            o Partido Liberal representa a voz da mudança e do progresso.
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left - Video/Image */}
          <div className="relative">
            <div className="aspect-video rounded-2xl overflow-hidden bg-party-blue flex items-center justify-center shadow-lg">
              <div className="text-center text-white p-8">
                <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-white/20 flex items-center justify-center cursor-pointer hover:bg-white/30 transition-colors">
                  <svg className="w-10 h-10 ml-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
                <p className="text-white/80">Vídeo Institucional</p>
              </div>
            </div>
            {/* Decorative Element */}
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-party-yellow rounded-lg -z-10" />
          </div>

          {/* Right - Values */}
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold text-foreground mb-6">
              Nossos Valores Fundamentais
            </h3>
            <div className="grid sm:grid-cols-2 gap-4">
              {values.map((value) => (
                <Card key={value.title} className="card-hover border-0 shadow-sm">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-lg bg-party-blue/10 flex items-center justify-center mb-4">
                      <value.icon className="h-6 w-6 text-party-blue" />
                    </div>
                    <h4 className="font-semibold text-foreground mb-2">
                      {value.title}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {value.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>

        {/* History Timeline */}
        <div className="mt-20">
          <h3 className="text-2xl font-semibold text-center text-foreground mb-12">
            Nossa Trajetória
          </h3>
          <div className="relative max-w-4xl mx-auto">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-0.5 bg-party-blue/20 hidden md:block" />

            {/* Timeline Items */}
            <div className="space-y-8">
              {timeline.map((item, index) => (
                <div
                  key={item.year}
                  className={`relative flex items-center ${
                    index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                  }`}
                >
                  <div className={`w-full md:w-1/2 ${index % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"}`}>
                    <div className="bg-white p-6 rounded-xl shadow-sm border inline-block">
                      <Badge className="bg-party-yellow text-party-blue-dark mb-2">
                        {item.year}
                      </Badge>
                      <h4 className="font-semibold text-foreground mb-1">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                  <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 w-4 h-4 rounded-full bg-party-blue border-4 border-white shadow" />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

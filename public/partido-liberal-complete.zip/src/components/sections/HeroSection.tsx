"use client";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Megaphone } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export function HeroSection() {
  return (
    <section id="inicio" className="relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/hero-bg.png"
          alt="Partido Liberal - Campanha"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-gradient-to-r from-party-blue/95 via-party-blue/85 to-party-blue/70" />
      </div>

      {/* Decorative Elements */}
      <div className="absolute top-20 right-10 w-64 h-64 bg-party-yellow/20 rounded-full blur-3xl" />
      <div className="absolute bottom-10 left-10 w-48 h-48 bg-white/10 rounded-full blur-2xl" />

      <div className="relative container mx-auto px-4 py-20 lg:py-32">
        <div className="max-w-4xl mx-auto text-center text-white">
          {/* Badge */}
          <Badge
            variant="outline"
            className="bg-white/10 border-white/20 text-white mb-6 px-4 py-2"
          >
            <Megaphone className="h-4 w-4 mr-2" />
            Eleições 2025 - Juntos pelo Futuro de Angola
          </Badge>

          {/* Main Heading */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
            Construindo um{" "}
            <span className="text-party-yellow">Angola Melhor</span>
            <br />
            para Todos
          </h1>

          {/* Subtitle */}
          <p className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl mx-auto">
            O Partido Liberal é a voz da mudança, da liberdade e do progresso.
            Junte-se a nós nesta jornada rumo a um futuro próspero e justo para todos os angolanos.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="#voluntarios">
              <Button size="lg" className="btn-cta px-8 py-6 text-lg">
                Seja Voluntário
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="#programa">
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent border-white text-white hover:bg-white hover:text-party-blue px-8 py-6 text-lg"
              >
                Conheça Nosso Programa
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 pt-8 border-t border-white/20">
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-party-yellow mb-2">15K+</div>
              <div className="text-sm text-white/70">Voluntários Ativos</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-party-yellow mb-2">18</div>
              <div className="text-sm text-white/70">Províncias Presentes</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-party-yellow mb-2">50+</div>
              <div className="text-sm text-white/70">Eventos Este Mês</div>
            </div>
            <div className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-party-yellow mb-2">100K+</div>
              <div className="text-sm text-white/70">Apoiantes</div>
            </div>
          </div>
        </div>
      </div>

      {/* Wave Divider */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M0 120L60 105C120 90 240 60 360 45C480 30 600 30 720 37.5C840 45 960 60 1080 67.5C1200 75 1320 75 1380 75L1440 75V120H1380C1320 120 1200 120 1080 120C960 120 840 120 720 120C600 120 480 120 360 120C240 120 120 120 60 120H0Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
}

import { createClient } from "@/lib/supabase/server";

// Fallback data when Supabase tables don't exist
const mockNews = [
  {
    id: '1',
    title: 'Partido Liberal lança programa de governo para 2024-2029',
    slug: 'programa-governo-2024-2029',
    summary: 'Propostas incluem investimentos massivos em saúde, educação e infraestrutura em todas as províncias.',
    content: 'O Partido Liberal apresentou hoje o seu programa de governo para o período 2024-2029, com propostas ambiciosas para transformar Angola.',
    category: 'comunicado',
    featured: true,
    published: true,
    author: 'Redação PL',
    views: 1543,
    createdAt: new Date('2024-01-15').toISOString(),
  },
  {
    id: '2',
    title: 'Comício em Saurimo reúne mais de 10 mil pessoas',
    slug: 'comicio-saurimo-10-mil',
    summary: 'Evento marcou o lançamento da campanha na província da Lunda Sul com forte presença de jovens.',
    content: 'Mais de 10 mil pessoas participaram do comício do Partido Liberal em Saurimo.',
    category: 'imprensa',
    featured: false,
    published: true,
    author: 'Nossa Equipe',
    views: 892,
    createdAt: new Date('2024-01-14').toISOString(),
  },
  {
    id: '3',
    title: 'Partido Liberal condena violência política',
    slug: 'condena-violencia-politica',
    summary: 'Nota oficial repudia atos de intolerância e convoca todos os partidos ao diálogo.',
    content: 'O Partido Liberal vem a público condenar veementemente todos os atos de violência política.',
    category: 'nota_oficial',
    featured: false,
    published: true,
    author: 'Secretaria-Geral',
    views: 654,
    createdAt: new Date('2024-01-13').toISOString(),
  },
  {
    id: '4',
    title: 'Candidatos do PL participam de debate televisivo',
    slug: 'debate-televisivo-candidatos',
    summary: 'Representantes apresentaram propostas para os setores de saúde e educação.',
    content: 'Os candidatos do Partido Liberal participaram de um debate televisivo.',
    category: 'imprensa',
    featured: false,
    published: true,
    author: 'Assessoria de Imprensa',
    views: 1234,
    createdAt: new Date('2024-01-12').toISOString(),
  },
];

const categoryColors: Record<string, string> = {
  comunicado: "bg-party-blue text-white",
  imprensa: "bg-party-yellow text-party-blue-dark",
  nota_oficial: "bg-green-100 text-green-700",
  artigo: "bg-purple-100 text-purple-700",
};

const categoryLabels: Record<string, string> = {
  comunicado: "Comunicado",
  imprensa: "Imprensa",
  nota_oficial: "Nota Oficial",
  artigo: "Artigo",
};

// Helper function to format dates consistently (avoid hydration mismatch)
const MONTHS_PT = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

function formatDate(dateStr: string) {
  const date = new Date(dateStr);
  return `${date.getDate()} de ${MONTHS_PT[date.getMonth()]} de ${date.getFullYear()}`;
}

export async function NewsSection() {
  const supabase = await createClient();
  
  let news = mockNews;
  
  try {
    const { data, error } = await supabase
      .from('News')
      .select('*')
      .eq('published', true)
      .order('createdAt', { ascending: false })
      .limit(4);

    if (!error && data && data.length > 0) {
      news = data;
    }
  } catch (e) {
    // Use mock data if Supabase fails
    console.log('Using mock news data');
  }

  const featuredNews = news.find((n: any) => n.featured) || news[0];
  const regularNews = news.filter((n: any) => n.id !== featuredNews?.id);

  return (
    <section id="noticias" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-12">
          <div>
            <span className="inline-block px-4 py-1.5 bg-party-blue/10 text-party-blue text-sm font-medium rounded-full mb-4">
              Notícias
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Últimas <span className="text-party-blue">Notícias</span>
            </h2>
          </div>
          <a href="#noticias" className="mt-4 md:mt-0 inline-flex items-center px-4 py-2 border border-party-blue text-party-blue hover:bg-party-blue hover:text-white rounded-lg transition-colors">
            Ver Todas
            <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Featured News */}
          {featuredNews && (
            <div className="bg-card rounded-xl shadow-md overflow-hidden group lg:row-span-2">
              <div className="h-64 bg-gradient-to-br from-party-blue to-party-blue-dark relative">
                <span className={`absolute top-4 left-4 px-3 py-1 rounded-full text-xs font-medium ${categoryColors[featuredNews.category] || "bg-gray-500 text-white"}`}>
                  {categoryLabels[featuredNews.category] || featuredNews.category}
                </span>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-semibold text-foreground group-hover:text-party-blue transition-colors mb-3">
                  {featuredNews.title}
                </h3>
                <p className="text-muted-foreground mb-4">{featuredNews.summary}</p>
                <div className="flex items-center justify-between text-sm text-muted-foreground">
                  <span>{formatDate(featuredNews.createdAt)}</span>
                  <span className="text-party-blue font-medium">{featuredNews.author}</span>
                </div>

                {/* WhatsApp Share */}
                <a
                  href={`https://wa.me/?text=${encodeURIComponent(featuredNews.title + ' - Partido Liberal')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 flex items-center justify-center gap-2 w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg transition-colors"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  Compartilhar no WhatsApp
                </a>
              </div>
            </div>
          )}

          {/* Regular News */}
          <div className="space-y-6">
            {regularNews.map((item: any) => (
              <div
                key={item.id}
                className="bg-card rounded-lg shadow-sm overflow-hidden group flex flex-col sm:flex-row"
              >
                <div className="w-full sm:w-32 h-24 bg-gradient-to-br from-party-blue/80 to-party-blue-dark/80 flex-shrink-0" />
                <div className="flex-1 p-4">
                  <div className="flex items-start justify-between gap-2">
                    <span className={`px-2 py-0.5 rounded text-xs ${categoryColors[item.category] || "bg-gray-500 text-white"}`}>
                      {categoryLabels[item.category] || item.category}
                    </span>
                    <a
                      href={`https://wa.me/?text=${encodeURIComponent(item.title + ' - Partido Liberal')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-green-600 transition-colors"
                    >
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                    </a>
                  </div>
                  <h4 className="font-semibold text-foreground mt-2 group-hover:text-party-blue transition-colors line-clamp-2">
                    {item.title}
                  </h4>
                  <p className="text-xs text-muted-foreground mt-1">{formatDate(item.createdAt)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

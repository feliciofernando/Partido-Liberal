"use client";

import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart3, 
  TrendingUp, 
  MapPin, 
  Users, 
  Clock,
  RefreshCw,
  CheckCircle2,
} from "lucide-react";
import { useState } from "react";

const mockResults = [
  { province: "Luanda", votes: 125000, percentage: 62, reported: 95 },
  { province: "Benguela", votes: 45000, percentage: 58, reported: 88 },
  { province: "Huambo", votes: 38000, percentage: 55, reported: 82 },
  { province: "Huíla", votes: 32000, percentage: 54, reported: 75 },
  { province: "Cabinda", votes: 18000, percentage: 65, reported: 90 },
  { province: "Lunda Sul", votes: 12000, percentage: 70, reported: 85 },
];

// Formatação consistente sem depender de locale
function formatVotes(votes: number): string {
  if (votes >= 1000) {
    return `${Math.floor(votes / 1000)} mil`;
  }
  return String(votes);
}

export function ElectionResultsSection() {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => setIsRefreshing(false), 1500);
  };

  const totalVotes = mockResults.reduce((acc, curr) => acc + curr.votes, 0);
  const avgPercentage = Math.round(mockResults.reduce((acc, curr) => acc + curr.percentage, 0) / mockResults.length);

  return (
    <section id="resultados" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge className="bg-party-blue/10 text-party-blue mb-4">
            <BarChart3 className="h-3 w-3 mr-1" />
            Resultados
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Acompanhamento <span className="text-party-blue">Eleitoral</span>
          </h2>
          <p className="text-lg text-muted-foreground">
            Acompanhe em tempo real os resultados apurados pelos nossos fiscais.
            Transparência e democracia em primeiro lugar.
          </p>
        </div>

        {/* Status Banner */}
        <Card className="mb-8 border-0 shadow-lg bg-gradient-to-r from-party-blue to-party-blue-dark text-white">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                  <CheckCircle2 className="h-6 w-6 text-party-yellow" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg">Apuração em Andamento</h3>
                  <p className="text-white/80 text-sm">Última atualização: há 5 minutos</p>
                </div>
              </div>
              <Button
                onClick={handleRefresh}
                variant="outline"
                className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              >
                <RefreshCw className={`mr-2 h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
                Atualizar
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-party-blue mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">{avgPercentage}%</div>
              <div className="text-sm text-muted-foreground">Média Nacional</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 text-party-blue mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">270K</div>
              <div className="text-sm text-muted-foreground">Votos Apurados</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <MapPin className="h-8 w-8 text-party-blue mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">18</div>
              <div className="text-sm text-muted-foreground">Províncias</div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-md">
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 text-party-blue mx-auto mb-2" />
              <div className="text-2xl font-bold text-foreground">85%</div>
              <div className="text-sm text-muted-foreground">Mesas Apuradas</div>
            </CardContent>
          </Card>
        </div>

        {/* Results by Province */}
        <Card className="border-0 shadow-lg">
          <CardHeader className="pb-2">
            <h3 className="text-lg font-semibold text-foreground">Resultados por Província</h3>
            <p className="text-sm text-muted-foreground">Dados apurados pelos fiscais do Partido Liberal</p>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {mockResults.map((result, index) => (
                <div key={result.province} className="p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-medium text-muted-foreground w-6">{index + 1}</span>
                      <span className="font-medium text-foreground">{result.province}</span>
                      <Badge variant="outline" className="text-xs">
                        {result.reported}% apurado
                      </Badge>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-party-blue text-lg">{result.percentage}%</span>
                      <p className="text-xs text-muted-foreground">
                        {formatVotes(result.votes)} votos
                      </p>
                    </div>
                  </div>
                  <Progress value={result.percentage} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Disclaimer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">
            ⚠️ Estes são dados preliminares apurados pelos fiscais do Partido Liberal.
            Os resultados oficiais serão divulgados pela Comissão Nacional Eleitoral.
          </p>
        </div>
      </div>
    </section>
  );
}

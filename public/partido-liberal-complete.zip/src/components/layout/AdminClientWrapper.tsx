'use client'

import { AdminProvider } from '../admin/AdminProvider'
import { AdminManager } from '../admin/AdminManager'

export function AdminClientWrapper({ children }: { children: React.ReactNode }) {
  return (
    <AdminProvider>
      {children}
      <AdminManager />
    </AdminProvider>
  )
}

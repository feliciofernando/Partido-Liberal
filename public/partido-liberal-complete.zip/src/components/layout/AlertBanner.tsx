"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Bell, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Alert {
  id: string;
  title: string;
  message: string;
  type: string;
}

// Dados estáticos para evitar erro de tabela
const defaultAlert: Alert = {
  id: "1",
  title: "Grande Comício em Luanda",
  message: "Não perca o lançamento da campanha em Luanda no dia 20 de Fevereiro!",
  type: "urgente",
};

export function AlertBanner() {
  const [isVisible, setIsVisible] = useState(true);

  // Sempre mostrar o alerta padrão
  const alert = defaultAlert;

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: -100, opacity: 0 }}
        className="relative bg-gradient-to-r from-party-blue to-party-blue-dark text-white"
      >
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-3 gap-4">
            <div className="flex items-center gap-3 flex-1">
              <div className="flex-shrink-0">
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                >
                  <Bell className="h-5 w-5 text-party-yellow" />
                </motion.div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{alert.title}</p>
                <p className="text-xs text-white/80 truncate hidden sm:block">{alert.message}</p>
              </div>
              <Button
                size="sm"
                className="bg-party-yellow text-party-blue-dark hover:bg-party-yellow-dark text-xs hidden md:flex"
              >
                Saiba Mais
                <ArrowRight className="ml-1 h-3 w-3" />
              </Button>
            </div>
            <button
              onClick={() => setIsVisible(false)}
              className="flex-shrink-0 p-1 hover:bg-white/10 rounded transition-colors"
              aria-label="Fechar alerta"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

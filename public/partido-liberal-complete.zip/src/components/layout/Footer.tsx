import Link from "next/link";
import { Vote, Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from "lucide-react";

const footerLinks = {
  partido: [
    { name: "Nossa História", href: "#partido" },
    { name: "Estatutos", href: "#estatutos" },
    { name: "Diretrizes", href: "#diretrizes" },
    { name: "Símbolos", href: "#simbolos" },
  ],
  participar: [
    { name: "Seja Voluntário", href: "#voluntarios" },
    { name: "Fiscal de Mesa", href: "#fiscal" },
    { name: "Doações", href: "#doacoes" },
    { name: "Kit Digital", href: "#kit" },
  ],
  informacao: [
    { name: "Notícias", href: "#noticias" },
    { name: "Eventos", href: "#eventos" },
    { name: "Programa de Governo", href: "#programa" },
    { name: "Ouvidoria", href: "#ouvidoria" },
  ],
};

const socialLinks = [
  { name: "Facebook", icon: Facebook, href: "#" },
  { name: "Twitter", icon: Twitter, href: "#" },
  { name: "Instagram", icon: Instagram, href: "#" },
  { name: "Youtube", icon: Youtube, href: "#" },
];

export function Footer() {
  return (
    <footer className="bg-party-blue text-white">
      {/* Main Footer */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-white">
                <Vote className="h-7 w-7 text-party-blue" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold leading-tight">
                  PARTIDO LIBERAL
                </span>
                <span className="text-sm text-white/70 leading-tight">
                  Construindo o Futuro de Angola
                </span>
              </div>
            </div>
            <p className="text-white/80 text-sm mb-6 max-w-md">
              O Partido Liberal é comprometido com o desenvolvimento sustentável de Angola,
              promovendo a liberdade, a democracia e o bem-estar de todos os cidadãos angolanos.
            </p>

            {/* Contact Info */}
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-party-yellow" />
                <span className="text-white/80">Luanda, Angola</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-party-yellow" />
                <span className="text-white/80">+244 923 456 789</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-party-yellow" />
                <span className="text-white/80">contacto@partidoliberal.ao</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="flex gap-3 mt-6">
              {socialLinks.map((social) => (
                <Link
                  key={social.name}
                  href={social.href}
                  className="flex h-10 w-10 items-center justify-center rounded-full bg-white/10 hover:bg-party-yellow hover:text-party-blue transition-colors"
                  aria-label={social.name}
                >
                  <social.icon className="h-5 w-5" />
                </Link>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          <div>
            <h3 className="font-semibold text-party-yellow mb-4">O Partido</h3>
            <ul className="space-y-3">
              {footerLinks.partido.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-white/80 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-party-yellow mb-4">Participar</h3>
            <ul className="space-y-3">
              {footerLinks.participar.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-white/80 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-party-yellow mb-4">Informação</h3>
            <ul className="space-y-3">
              {footerLinks.informacao.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="text-sm text-white/80 hover:text-white transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-white/60">
              © {new Date().getFullYear()} Partido Liberal. Todos os direitos reservados.
            </p>
            <div className="flex gap-6 text-sm text-white/60">
              <Link href="#privacidade" className="hover:text-white transition-colors">
                Política de Privacidade
              </Link>
              <Link href="#termos" className="hover:text-white transition-colors">
                Termos de Uso
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}

import { NextRequest, NextResponse } from "next/server";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const slug = searchParams.get("slug");
    const category = searchParams.get("category");
    const featured = searchParams.get("featured") === "true";
    const limit = searchParams.get("limit") || "10";

    // Se tiver slug, retornar notícia específica
    if (slug) {
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/News?slug=eq.${slug}&select=*`,
        {
          headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          },
        }
      );

      if (!response.ok) {
        return NextResponse.json(
          { error: "Notícia não encontrada" },
          { status: 404 }
        );
      }

      const news = await response.json();
      const article = news?.[0];

      if (!article) {
        return NextResponse.json(
          { error: "Notícia não encontrada" },
          { status: 404 }
        );
      }

      // Incrementar views
      await fetch(
        `${SUPABASE_URL}/rest/v1/News?id=eq.${article.id}`,
        {
          method: 'PATCH',
          headers: {
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ views: article.views + 1 }),
        }
      );

      return NextResponse.json({ news: article });
    }

    // Listar notícias
    let url = `${SUPABASE_URL}/rest/v1/News?published=eq.true&select=id,title,slug,summary,category,image,createdAt,author,views,featured&order=createdAt.desc&limit=${limit}`;
    
    if (category) {
      url += `&category=eq.${category}`;
    }
    
    if (featured) {
      url += `&featured=eq.true`;
    }

    const response = await fetch(url, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      },
    });

    if (!response.ok) {
      return NextResponse.json({ news: [] });
    }

    const news = await response.json();

    return NextResponse.json({
      news: (news || []).map((n: any) => ({
        id: n.id,
        title: n.title,
        slug: n.slug,
        summary: n.summary,
        category: n.category,
        image: n.image,
        date: n.createdAt,
        author: n.author,
        views: n.views,
        featured: n.featured,
      })),
    });
  } catch (error) {
    console.error("Erro ao buscar notícias:", error);
    return NextResponse.json({ news: [] });
  }
}

import { NextRequest, NextResponse } from "next/server";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, name } = body;

    // Validação básica
    if (!email) {
      return NextResponse.json(
        { error: "Email é obrigatório" },
        { status: 400 }
      );
    }

    // Verificar se já existe
    const checkResponse = await fetch(
      `${SUPABASE_URL}/rest/v1/Subscriber?email=eq.${encodeURIComponent(email)}&select=id`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
      }
    );

    if (checkResponse.ok) {
      const existing = await checkResponse.json();
      if (existing && existing.length > 0) {
        return NextResponse.json({
          success: true,
          message: "Este email já está inscrito!",
        });
      }
    }

    // Criar subscriber
    const response = await fetch(`${SUPABASE_URL}/rest/v1/Subscriber`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
      },
      body: JSON.stringify({
        email,
        name: name || null,
        active: true,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error("Erro Supabase:", error);
      return NextResponse.json(
        { error: "Erro ao inscrever email" },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: "Inscrição realizada com sucesso!",
    });
  } catch (error) {
    console.error("Erro ao inscrever:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Subscriber?active=eq.true&select=id`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
      }
    );

    const subscribers = response.ok ? await response.json() : [];

    return NextResponse.json({
      total: subscribers?.length || 0,
    });
  } catch (error) {
    console.error("Erro ao buscar subscribers:", error);
    return NextResponse.json({ total: 0 });
  }
}

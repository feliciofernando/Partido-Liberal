import { NextResponse } from "next/server";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export async function GET() {
  try {
    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Alert?active=eq.true&order=createdAt.desc&limit=3`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
      }
    );

    if (!response.ok) {
      return NextResponse.json({ alerts: [] });
    }

    const alerts = await response.json();
    return NextResponse.json({ alerts: alerts || [] });
  } catch (error) {
    console.error("Erro ao buscar alertas:", error);
    return NextResponse.json({ alerts: [] });
  }
}

import { NextRequest, NextResponse } from "next/server";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const province = searchParams.get("province");
    const type = searchParams.get("type");
    const upcoming = searchParams.get("upcoming") === "true";

    let url = `${SUPABASE_URL}/rest/v1/Event?select=*&order=date.asc`;
    
    if (province) {
      url += `&province=eq.${province}`;
    }
    
    if (type) {
      url += `&type=eq.${type}`;
    }
    
    if (upcoming) {
      const now = new Date().toISOString();
      url += `&date=gte.${now}`;
    }

    const response = await fetch(url, {
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const error = await response.json();
      console.error("Erro Supabase:", error);
      return NextResponse.json({ events: [] });
    }

    const events = await response.json();

    // Buscar confirmações para cada evento
    const eventsWithConfirmations = await Promise.all(
      (events || []).map(async (event: any) => {
        const confirmResponse = await fetch(
          `${SUPABASE_URL}/rest/v1/EventConfirmation?eventId=eq.${event.id}&select=id`,
          {
            headers: {
              'apikey': SUPABASE_ANON_KEY,
              'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
            },
          }
        );
        const confirmations = confirmResponse.ok ? await confirmResponse.json() : [];
        return {
          ...event,
          confirmations: confirmations?.length || 0,
        };
      })
    );

    return NextResponse.json({ events: eventsWithConfirmations });
  } catch (error) {
    console.error("Erro ao buscar eventos:", error);
    return NextResponse.json({ events: [] });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { eventId, name, email, phone } = body;

    if (!eventId || !name) {
      return NextResponse.json(
        { error: "ID do evento e nome são obrigatórios" },
        { status: 400 }
      );
    }

    // Criar confirmação
    const response = await fetch(`${SUPABASE_URL}/rest/v1/EventConfirmation`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
      },
      body: JSON.stringify({
        eventId,
        name,
        email: email || null,
        phone: phone || null,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error("Erro Supabase:", error);
      return NextResponse.json(
        { error: "Erro ao confirmar presença" },
        { status: 500 }
      );
    }

    const confirmation = await response.json();

    return NextResponse.json({
      success: true,
      message: "Presença confirmada com sucesso!",
      data: confirmation?.[0] || confirmation,
    });
  } catch (error) {
    console.error("Erro ao confirmar presença:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { getAdminSession } from '@/lib/admin-auth'

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!

async function checkAuth() {
  const session = await getAdminSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }
  return null
}

// GET - List all leaders
export async function GET(request: NextRequest) {
  const authError = await checkAuth()
  if (authError) return authError

  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    
    if (id) {
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/Leader?id=eq.${id}&select=*`,
        {
          headers: {
            'apikey': SUPABASE_SERVICE_KEY,
            'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          },
        }
      )
      const data = await response.json()
      return NextResponse.json({ leader: data?.[0] || null })
    }

    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Leader?select=*&order=order.asc`,
      {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
        },
      }
    )
    const leaders = await response.json()
    return NextResponse.json({ leaders: leaders || [] })
  } catch (error) {
    console.error('Erro ao buscar líderes:', error)
    return NextResponse.json({ error: 'Erro ao buscar líderes' }, { status: 500 })
  }
}

// POST - Create leader
export async function POST(request: NextRequest) {
  const authError = await checkAuth()
  if (authError) return authError

  try {
    const body = await request.json()
    const slug = body.name
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '')

    const leaderData = {
      ...body,
      slug,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Leader`,
      {
        method: 'POST',
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation',
        },
        body: JSON.stringify(leaderData),
      }
    )

    if (!response.ok) {
      const error = await response.text()
      return NextResponse.json({ error: 'Erro ao criar líder', details: error }, { status: 500 })
    }

    const created = await response.json()
    return NextResponse.json({ success: true, leader: created?.[0] })
  } catch (error) {
    console.error('Erro ao criar líder:', error)
    return NextResponse.json({ error: 'Erro ao criar líder' }, { status: 500 })
  }
}

// PUT - Update leader
export async function PUT(request: NextRequest) {
  const authError = await checkAuth()
  if (authError) return authError

  try {
    const body = await request.json()
    const { id, ...data } = body

    if (!id) {
      return NextResponse.json({ error: 'ID é obrigatório' }, { status: 400 })
    }

    const slug = data.name
      ? data.name
          .toLowerCase()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '')
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/(^-|-$)/g, '')
      : undefined

    const updateData = {
      ...data,
      ...(slug && { slug }),
      updatedAt: new Date().toISOString(),
    }

    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Leader?id=eq.${id}`,
      {
        method: 'PATCH',
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation',
        },
        body: JSON.stringify(updateData),
      }
    )

    if (!response.ok) {
      return NextResponse.json({ error: 'Erro ao atualizar líder' }, { status: 500 })
    }

    const updated = await response.json()
    return NextResponse.json({ success: true, leader: updated?.[0] })
  } catch (error) {
    console.error('Erro ao atualizar líder:', error)
    return NextResponse.json({ error: 'Erro ao atualizar líder' }, { status: 500 })
  }
}

// DELETE - Delete leader
export async function DELETE(request: NextRequest) {
  const authError = await checkAuth()
  if (authError) return authError

  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'ID é obrigatório' }, { status: 400 })
    }

    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Leader?id=eq.${id}`,
      {
        method: 'DELETE',
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
        },
      }
    )

    if (!response.ok) {
      return NextResponse.json({ error: 'Erro ao apagar líder' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Erro ao apagar líder:', error)
    return NextResponse.json({ error: 'Erro ao apagar líder' }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { setAdminSession, clearAdminSession, ADMIN_CREDENTIALS } from '@/lib/admin-auth'

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (email === ADMIN_CREDENTIALS.email && password === ADMIN_CREDENTIALS.password) {
      await setAdminSession({ email, role: 'admin' })
      return NextResponse.json({ success: true, message: 'Login realizado com sucesso' })
    }

    return NextResponse.json(
      { success: false, message: 'Credenciais inválidas' },
      { status: 401 }
    )
  } catch (error) {
    console.error('Erro no login:', error)
    return NextResponse.json(
      { success: false, message: 'Erro ao processar login' },
      { status: 500 }
    )
  }
}

export async function DELETE() {
  await clearAdminSession()
  return NextResponse.json({ success: true, message: 'Sessão terminada' })
}

export async function GET() {
  // Check if admin is logged in
  const { getAdminSession } = await import('@/lib/admin-auth')
  const session = await getAdminSession()
  
  if (session) {
    return NextResponse.json({ authenticated: true, user: session })
  }
  
  return NextResponse.json({ authenticated: false })
}

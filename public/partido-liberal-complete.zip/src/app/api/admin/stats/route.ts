import { NextResponse } from 'next/server'
import { getAdminSession } from '@/lib/admin-auth'

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!

export async function GET() {
  const session = await getAdminSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }

  try {
    // Fetch counts from all tables
    const [
      newsRes,
      leadersRes,
      eventsRes,
      volunteersRes,
      complaintsRes,
      subscribersRes,
      kitItemsRes,
      alertsRes
    ] = await Promise.all([
      fetch(`${SUPABASE_URL}/rest/v1/News?select=id`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Prefer': 'count=exact',
        },
      }),
      fetch(`${SUPABASE_URL}/rest/v1/Leader?select=id`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Prefer': 'count=exact',
        },
      }),
      fetch(`${SUPABASE_URL}/rest/v1/Event?select=id`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Prefer': 'count=exact',
        },
      }),
      fetch(`${SUPABASE_URL}/rest/v1/Volunteer?select=id`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Prefer': 'count=exact',
        },
      }),
      fetch(`${SUPABASE_URL}/rest/v1/Complaint?select=id`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Prefer': 'count=exact',
        },
      }),
      fetch(`${SUPABASE_URL}/rest/v1/Subscriber?select=id`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Prefer': 'count=exact',
        },
      }),
      fetch(`${SUPABASE_URL}/rest/v1/KitItem?select=id`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Prefer': 'count=exact',
        },
      }),
      fetch(`${SUPABASE_URL}/rest/v1/Alert?select=id&active=eq.true`, {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
        },
      }),
    ])

    const [
      news,
      leaders,
      events,
      volunteers,
      complaints,
      subscribers,
      kitItems,
      alerts
    ] = await Promise.all([
      newsRes.json(),
      leadersRes.json(),
      eventsRes.json(),
      volunteersRes.json(),
      complaintsRes.json(),
      subscribersRes.json(),
      kitItemsRes.json(),
      alertsRes.json(),
    ])

    // Get pending volunteers and complaints
    const pendingVolunteersRes = await fetch(
      `${SUPABASE_URL}/rest/v1/Volunteer?select=id&status=eq.pending`,
      {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
        },
      }
    )
    const pendingComplaintsRes = await fetch(
      `${SUPABASE_URL}/rest/v1/Complaint?select=id&status=eq.pending`,
      {
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
        },
      }
    )
    
    const pendingVolunteers = await pendingVolunteersRes.json()
    const pendingComplaints = await pendingComplaintsRes.json()

    return NextResponse.json({
      stats: {
        news: news?.length || 0,
        leaders: leaders?.length || 0,
        events: events?.length || 0,
        volunteers: volunteers?.length || 0,
        pendingVolunteers: pendingVolunteers?.length || 0,
        complaints: complaints?.length || 0,
        pendingComplaints: pendingComplaints?.length || 0,
        subscribers: subscribers?.length || 0,
        kitItems: kitItems?.length || 0,
        activeAlerts: alerts?.length || 0,
      }
    })
  } catch (error) {
    console.error('Erro ao buscar estatísticas:', error)
    return NextResponse.json({ error: 'Erro ao buscar estatísticas' }, { status: 500 })
  }
}

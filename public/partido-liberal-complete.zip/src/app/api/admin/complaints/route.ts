import { NextRequest, NextResponse } from 'next/server'
import { getAdminSession } from '@/lib/admin-auth'

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!
const SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY!

async function checkAuth() {
  const session = await getAdminSession()
  if (!session) {
    return NextResponse.json({ error: 'Não autorizado' }, { status: 401 })
  }
  return null
}

// GET - List all complaints
export async function GET(request: NextRequest) {
  const authError = await checkAuth()
  if (authError) return authError

  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')
    const status = searchParams.get('status')
    
    if (id) {
      const response = await fetch(
        `${SUPABASE_URL}/rest/v1/Complaint?id=eq.${id}&select=*`,
        {
          headers: {
            'apikey': SUPABASE_SERVICE_KEY,
            'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          },
        }
      )
      const data = await response.json()
      return NextResponse.json({ complaint: data?.[0] || null })
    }

    let url = `${SUPABASE_URL}/rest/v1/Complaint?select=*&order=createdAt.desc`
    if (status) {
      url += `&status=eq.${status}`
    }

    const response = await fetch(url, {
      headers: {
        'apikey': SUPABASE_SERVICE_KEY,
        'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
      },
    })
    const complaints = await response.json()
    return NextResponse.json({ complaints: complaints || [] })
  } catch (error) {
    console.error('Erro ao buscar denúncias:', error)
    return NextResponse.json({ error: 'Erro ao buscar denúncias' }, { status: 500 })
  }
}

// PUT - Update complaint (respond, change status)
export async function PUT(request: NextRequest) {
  const authError = await checkAuth()
  if (authError) return authError

  try {
    const body = await request.json()
    const { id, ...data } = body

    if (!id) {
      return NextResponse.json({ error: 'ID é obrigatório' }, { status: 400 })
    }

    const updateData = {
      ...data,
      updatedAt: new Date().toISOString(),
    }

    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Complaint?id=eq.${id}`,
      {
        method: 'PATCH',
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
          'Content-Type': 'application/json',
          'Prefer': 'return=representation',
        },
        body: JSON.stringify(updateData),
      }
    )

    if (!response.ok) {
      return NextResponse.json({ error: 'Erro ao atualizar denúncia' }, { status: 500 })
    }

    const updated = await response.json()
    return NextResponse.json({ success: true, complaint: updated?.[0] })
  } catch (error) {
    console.error('Erro ao atualizar denúncia:', error)
    return NextResponse.json({ error: 'Erro ao atualizar denúncia' }, { status: 500 })
  }
}

// DELETE - Delete complaint
export async function DELETE(request: NextRequest) {
  const authError = await checkAuth()
  if (authError) return authError

  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'ID é obrigatório' }, { status: 400 })
    }

    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Complaint?id=eq.${id}`,
      {
        method: 'DELETE',
        headers: {
          'apikey': SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${SUPABASE_SERVICE_KEY}`,
        },
      }
    )

    if (!response.ok) {
      return NextResponse.json({ error: 'Erro ao apagar denúncia' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Erro ao apagar denúncia:', error)
    return NextResponse.json({ error: 'Erro ao apagar denúncia' }, { status: 500 })
  }
}

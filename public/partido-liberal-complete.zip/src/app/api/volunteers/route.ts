import { NextRequest, NextResponse } from "next/server";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      name,
      email,
      phone,
      province,
      municipality,
      availability,
      interests,
      experience,
      isFiscal,
    } = body;

    // Validação básica
    if (!name || !email || !phone || !province) {
      return NextResponse.json(
        { error: "Campos obrigatórios não preenchidos" },
        { status: 400 }
      );
    }

    // Verificar se já existe
    const checkResponse = await fetch(
      `${SUPABASE_URL}/rest/v1/Volunteer?email=eq.${encodeURIComponent(email)}&select=id`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
      }
    );

    if (checkResponse.ok) {
      const existing = await checkResponse.json();
      if (existing && existing.length > 0) {
        return NextResponse.json(
          { error: "Já existe um cadastro com este email" },
          { status: 400 }
        );
      }
    }

    // Criar voluntário
    const response = await fetch(`${SUPABASE_URL}/rest/v1/Volunteer`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
      },
      body: JSON.stringify({
        name,
        email,
        phone,
        province,
        municipality: municipality || null,
        availability: availability || null,
        interests: interests ? JSON.stringify(interests) : null,
        experience: experience || null,
        isFiscal: isFiscal || false,
        status: "pendente",
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error("Erro Supabase:", error);
      return NextResponse.json(
        { error: "Erro ao cadastrar voluntário" },
        { status: 500 }
      );
    }

    const volunteer = await response.json();

    return NextResponse.json({
      success: true,
      message: "Cadastro realizado com sucesso!",
      data: volunteer?.[0] || volunteer,
    });
  } catch (error) {
    console.error("Erro ao cadastrar voluntário:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    // Buscar voluntários ativos
    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Volunteer?status=eq.ativo&select=id,name,province,availability,isFiscal&order=createdAt.desc&limit=10`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
      }
    );

    const volunteers = response.ok ? await response.json() : [];

    // Contar total
    const countResponse = await fetch(
      `${SUPABASE_URL}/rest/v1/Volunteer?status=in.(ativo,pendente)&select=id`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          'Prefer': 'count=exact',
        },
      }
    );

    const totalVolunteers = countResponse.ok ? (await countResponse.json())?.length || 0 : 0;

    // Contar fiscais
    const fiscalResponse = await fetch(
      `${SUPABASE_URL}/rest/v1/Volunteer?isFiscal=eq.true&select=id`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
      }
    );

    const totalFiscals = fiscalResponse.ok ? (await fiscalResponse.json())?.length || 0 : 0;

    return NextResponse.json({
      volunteers: volunteers || [],
      stats: {
        total: totalVolunteers,
        fiscals: totalFiscals,
      },
    });
  } catch (error) {
    console.error("Erro ao buscar voluntários:", error);
    return NextResponse.json({
      volunteers: [],
      stats: { total: 0, fiscals: 0 },
    });
  }
}

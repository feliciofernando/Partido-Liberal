import { NextRequest, NextResponse } from "next/server";

const SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const SUPABASE_ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      type,
      name,
      email,
      phone,
      province,
      subject,
      message,
      anonymous,
    } = body;

    // Validação básica
    if (!type || !subject || !message) {
      return NextResponse.json(
        { error: "Campos obrigatórios não preenchidos" },
        { status: 400 }
      );
    }

    // Criar denúncia
    const response = await fetch(`${SUPABASE_URL}/rest/v1/Complaint`, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        'Content-Type': 'application/json',
        'Prefer': 'return=representation',
      },
      body: JSON.stringify({
        type,
        name: anonymous ? null : name,
        email: anonymous ? null : email,
        phone: anonymous ? null : phone,
        province: province || null,
        subject,
        message,
        anonymous: anonymous || false,
        status: "pendente",
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error("Erro Supabase:", error);
      return NextResponse.json(
        { error: "Erro ao enviar mensagem" },
        { status: 500 }
      );
    }

    const complaint = await response.json();

    return NextResponse.json({
      success: true,
      message: "Mensagem enviada com sucesso!",
      data: complaint?.[0] || complaint,
    });
  } catch (error) {
    console.error("Erro ao enviar mensagem:", error);
    return NextResponse.json(
      { error: "Erro interno do servidor" },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const response = await fetch(
      `${SUPABASE_URL}/rest/v1/Complaint?select=type`,
      {
        headers: {
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
      }
    );

    const complaints = response.ok ? await response.json() : [];

    // Agrupar por tipo
    const stats = (complaints || []).reduce((acc: Record<string, number>, item: any) => {
      acc[item.type] = (acc[item.type] || 0) + 1;
      return acc;
    }, {});

    return NextResponse.json({
      stats: Object.entries(stats).map(([type, count]) => ({
        type,
        count,
      })),
    });
  } catch (error) {
    console.error("Erro ao buscar estatísticas:", error);
    return NextResponse.json({ stats: [] });
  }
}

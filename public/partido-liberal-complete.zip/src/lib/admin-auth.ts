import { cookies } from 'next/headers'
import { SignJWT, jwtVerify } from 'jose'

const SECRET_KEY = new TextEncoder().encode(
  process.env.ADMIN_SECRET || 'partido-liberal-admin-secret-2024'
)

export interface AdminUser {
  email: string
  role: 'admin'
}

export async function signAdminToken(user: AdminUser): Promise<string> {
  return new SignJWT({ ...user })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('24h')
    .sign(SECRET_KEY)
}

export async function verifyAdminToken(token: string): Promise<AdminUser | null> {
  try {
    const { payload } = await jwtVerify(token, SECRET_KEY)
    return payload as unknown as AdminUser
  } catch {
    return null
  }
}

export async function getAdminSession(): Promise<AdminUser | null> {
  const cookieStore = await cookies()
  const token = cookieStore.get('admin-token')?.value
  
  if (!token) return null
  
  return verifyAdminToken(token)
}

export async function setAdminSession(user: AdminUser): Promise<void> {
  const cookieStore = await cookies()
  const token = await signAdminToken(user)
  
  cookieStore.set('admin-token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24, // 24 hours
    path: '/',
  })
}

export async function clearAdminSession(): Promise<void> {
  const cookieStore = await cookies()
  cookieStore.delete('admin-token')
}

// Admin credentials
export const ADMIN_CREDENTIALS = {
  email: 'feliciofernando567@gmail.com',
  password: '946788879Gh!!'
}
